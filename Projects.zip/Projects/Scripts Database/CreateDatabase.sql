-- Verifique se a pasta C:\temp existe. Caso contrário, crie-a antes de executar este script.

-- Criação do banco de dados no SQL Server
CREATE DATABASE Projeto
ON PRIMARY
(
    NAME = 'Projeto_Data',
    FILENAME = 'C:\temp\Projeto_Data.mdf', -- Arquivo de dados principal
    SIZE = 10MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10MB
)
LOG ON
(
    NAME = 'Projeto_Log',
    FILENAME = 'C:\temp\Projeto_Log.ldf', -- Arquivo de log
    SIZE = 5MB,
    MAXSIZE = 50MB,
    FILEGROWTH = 5MB
);

-- Mensagem para indicar que o banco foi criado
PRINT 'Banco de dados Projeto criado com sucesso no diretório C:\temp.';