
USE [PROJETO]
GO

/****** Object:  Table [dbo].[Produtos]******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Produtos](
	[CdProduto] [int] IDENTITY(1,1) NOT NULL,
	[DsProduto] [varchar](255) NOT NULL,
	[InAtivo] [bit] NOT NULL,
	[DsComplemento] [varchar](255) NULL,
	[DsInfTec] [varchar](255) NULL,
	[DsCaractAplic] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[CdProduto] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Produtos] ADD  DEFAULT ((1)) FOR [InAtivo]
GO
